---
name: evidence-review
description: Review evidence before making claims.
---
Compare sources and clearly identify uncertainty.
